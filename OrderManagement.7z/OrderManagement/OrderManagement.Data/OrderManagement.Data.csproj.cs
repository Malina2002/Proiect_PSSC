﻿namespace OrderManagement.OrderManagement.Data;

public class OrderManagement_Data_csproj
{
    
}