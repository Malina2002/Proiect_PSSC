﻿using System;
using System.Collections.Generic;

namespace OrderManagement.Domain.Entities
{
    public class Order
    {
        public Guid Id { get; private set; }
        public string CustomerName { get; private set; }
        public List<OrderItem> Items { get; private set; }
        public DateTime CreatedAt { get; private set; }
        public OrderStatus Status { get; private set; }

        public Order(string customerName, List<OrderItem> items)
        {
            Id = Guid.NewGuid();
            CustomerName = customerName;
            Items = items ?? throw new ArgumentNullException(nameof(items));
            CreatedAt = DateTime.UtcNow;
            Status = OrderStatus.Pending;
        }

        public void MarkAsShipped()
        {
            if (Status != OrderStatus.Pending)
                throw new InvalidOperationException("Order cannot be shipped.");
            Status = OrderStatus.Shipped;
        }
    }

    public enum OrderStatus
    {
        Pending,
        Shipped,
        Cancelled
    }

    public class OrderItem
    {
        public string ProductName { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public decimal Price { get; set; }
    }
}