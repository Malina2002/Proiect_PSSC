﻿using Microsoft.EntityFrameworkCore;
using OrderManagement.Data;

var builder = WebApplication.CreateBuilder(args);

// Adaugă DbContext
builder.Services.AddDbContext<OrderDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

var app = builder.Build();
app.MapControllers();
app.Run();